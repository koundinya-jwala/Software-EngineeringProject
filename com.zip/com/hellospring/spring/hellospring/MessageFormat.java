
package com.hellospring.spring.hellospring;

/**
 *
 * @author User
 */
public class MessageFormat {
    
    public static boolean isCorrectFormat(String message)
    {
        String[] array;
        if(message.indexOf(";")<=0)
        {
            return false;
        }
        
        array=message.split(";");
        if(array==null)
            return false;
        if(array[0].isEmpty() && array[1].isEmpty())
            return false;
        else if(MessageFormat.isInteger(array[0])==false && MessageFormat.isInteger(array[1])==false)
            return false;
        else if(message.charAt(message.length()-1)!=';')
            return false;
            
            
        return true;
    }
    
    public static boolean isInteger(String s) {
    return isInteger(s,10);
}

    public static boolean isInteger(String s, int radix) {
        if(s.isEmpty()) return false;
        for(int i = 0; i < s.length(); i++) {
            if(i == 0 && s.charAt(i) == '-') {
                if(s.length() == 1) return false;
                else continue;
        }
        if(Character.digit(s.charAt(i),radix) < 0) return false;
    }
    return true;
}
}
