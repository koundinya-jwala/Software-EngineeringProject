
package com.hellospring.spring.hellospring;

import com.hellospring.spring.hellospring.RequestManager.RequestInterface;
import com.hellospring.spring.hellospring.DatabaseManager.DatabaseManager;
import com.hellospring.spring.hellospring.RequestManager.RequestManager;
import com.hellospring.spring.hellospring.SessionManager.SessionManager;
import java.nio.channels.SocketChannel;


public class ThreadManager implements Runnable {
    static  ThreadGroup threadlist=new ThreadGroup("Our Clients");
    
    public void run()
    {
        
    }
    private void manageThread()
    {
        
    }
    static void createThread(String request, SocketChannel channel)
    {
        int securityNumber=0;
        RequestManager requestManager=RequestManager.generateRequestInstance(request,new DatabaseManager(),new SessionManager(),securityNumber);
        Thread newThread=new Thread(threadlist, requestManager);
        System.out.println("THREAD created");
        newThread.start();
    }

}
