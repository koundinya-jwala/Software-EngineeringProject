/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hellospring.spring.hellospring.RequestManager.ProductManager;

import com.hellospring.spring.hellospring.DatabaseManager.DatabaseManager;
import com.hellospring.spring.hellospring.SessionManager.SessionManager;
import java.io.*;
import java.util.*;

/**
 *
 * @author User
 */
 public class ProductManager implements ProductInterface {
    String request;
    String productTitle;
    String[] requestArray;
    DatabaseManager database;
    SessionManager session;
    
    ProductManager(String request,DatabaseManager database,SessionManager session)
    {
        this.database=database;
        this.session=session;
        this.request=request;
    }
    public String getProductData() 
    {
        String line;
        String[] array;
        try
        {
            Scanner sc=new Scanner(new File("C:\\Users\\User\\Documents\\NetBeansProjects\\HelloSpring\\src\\main\\java\\com\\hellospring\\spring\\hellospring\\RequestManager\\ProductManager\\Product"));
            while(sc.hasNext())
            {
                line=sc.nextLine();
                array=line.split(";");
                if(array[0].equals(request.split(";")[1]))
                    return array[1];
            }
        
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
        
    }
    private void setProductTitle()
    {
        this.requestArray=request.split(";") ;
        this.productTitle=this.requestArray[1];
    }
    private void getProductDescriptionDatabase()
    {
        
    }
        public static ProductInterface generateProductInstance(String request,DatabaseManager database,SessionManager session)
    {
        return new ProductManager( request,database, session);
    }
}
