/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hellospring.spring.hellospring.RequestManager;

import com.hellospring.spring.hellospring.DatabaseManager.DatabaseManager;
import com.hellospring.spring.hellospring.SessionManager.SessionManager;

/**
 *
 * @author User
 */
public interface RequestInterface {

    /**
     *
     * @param request
     * @param database
     * @param session
     * @param securityNumber
     * @return
     */
    
    
    public void executeRequest();
    
    
}
