/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hellospring.spring.hellospring.RequestManager;

import com.hellospring.spring.hellospring.DatabaseManager.DatabaseManager;
import com.hellospring.spring.hellospring.RequestManager.ProductManager.ProductInterface;
import com.hellospring.spring.hellospring.RequestManager.ProductManager.ProductManager;
import com.hellospring.spring.hellospring.SessionManager.SessionManager;
/**
 *
 * @author User
 */
 public class RequestManager implements Runnable , RequestInterface {
    
    DatabaseManager database;
    SessionManager session;
    String request;
    int requestType;
    RequestManager(String request,DatabaseManager database,SessionManager session,int securityNumber)
    {
        if(isValidSecurityNumber(securityNumber))
        {
            this.database=database;
            this.session=session;
            this.request=request;
        }
        
    }
    public void run()
    {
        executeRequest();
    }
    private boolean isValidSecurityNumber(int securityNumber)
    {
        return true;
    }

    @Override
   public void executeRequest()
   {
        System.out.println(handleRequest());
   }
    private String handleRequest()
    {
        this.requestType=new Integer(this.request.charAt(0));
        System.out.println("request----"+this.request);
        char i=this.request.charAt(0);
        System.out.println(i);
        
        switch(i)
        {
            case '1':ProductInterface product=ProductManager.generateProductInstance(request,database,session);
                    return (product.getProductData());
            
        }
        return "";
    }
    
    public static RequestManager generateRequestInstance(String request,DatabaseManager database,SessionManager session,int securityNumber)
    {
     return  new RequestManager(request,database, session,securityNumber);  
    }
    
}
