/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hellospring.spring.hellospring;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/**
 *
 * @author User
 */
public class Server implements Runnable {
    private Selector selector;
    private Map<SocketChannel,List> dataMapper=new HashMap<>();
    private ServerSocketChannel serverChannel;
    private Iterator keys;
    private InetSocketAddress listenAddress;
    String string1="Carpet;",string2="Pots;";
    Server(String address, int port)
    {
        listenAddress=new InetSocketAddress(address, port);
    }
    public void  run()
    {
        try
        {
            startServer();            
        }
        catch(IOException e)
        {
            System.out.println("");
        }
        
    }
    private void startServer() throws IOException
    {
        SelectionKey key;
        
        this.selector=Selector.open();
        serverChannel=ServerSocketChannel.open();
        serverChannel.configureBlocking(false);
        serverChannel.socket().bind(listenAddress);
        serverChannel.register(selector, SelectionKey.OP_ACCEPT);
        System.out.println("Server starrted");
        
        while(true)
        {
        this.selector.select();
        keys=this.selector.selectedKeys().iterator();
        while(keys.hasNext())
        {
            key=(SelectionKey)keys.next();
            keys.remove();
            
            if(!key.isValid())
            {
                continue;
            }
            if(key.isAcceptable())
            {
                this.accept(key);
            }
            else if(key.isReadable())
            {
                this.read(key);
            }
            
        }
     }
        
    }
    
     private void accept(SelectionKey key) throws IOException {
        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
        SocketChannel channel = serverChannel.accept();
        channel.configureBlocking(false);
        Socket socket = channel.socket();
        SocketAddress remoteAddr = socket.getRemoteSocketAddress();
        System.out.println("Connected to: " + remoteAddr);

        dataMapper.put(channel, new LinkedList());
        channel.register(this.selector, SelectionKey.OP_READ);

    }
     
      private void read(SelectionKey key) throws IOException {
        SocketChannel channel;
        ByteBuffer buffer;
        int numRead;
        String message;
        
        
        channel=(SocketChannel)key.channel();
        buffer=ByteBuffer.allocate(1024);
        numRead = -1;
        numRead = channel.read(buffer);
        
        if (numRead == -1) {
            this.dataMapper.remove(channel);
            Socket socket = channel.socket();
            SocketAddress remoteAddr = socket.getRemoteSocketAddress();
            System.out.println("Connection closed by client: " + remoteAddr);
            channel.close();
            key.cancel();
            return;
        }
        
        byte[] data = new byte[numRead];
        System.arraycopy(buffer.array(), 0, data, 0, numRead);
        System.out.println("Got: " + new String(data));
        message=buffer.toString();
        System.out.println(message);
        ThreadManager.createThread(new String(data),channel);
        
        if(new String(data).charAt(2)=='1')
        {
            buffer=ByteBuffer.wrap(string1.getBytes());
        }
        else if(new String(data).charAt(2)=='2')
        {
            buffer=ByteBuffer.wrap(string2.getBytes());
        }
        channel.write(buffer);
    } 
}
