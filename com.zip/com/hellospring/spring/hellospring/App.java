package com.hellospring.spring.hellospring;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 
public class App 
{
    public static void main(String[] args )
    {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("classpath:/META-INF/spring-config.xml");
        DoSomething ds = (DoSomething)appContext.getBean("doSomething");
        System.out.println(ds.toString());
        
    }
}
