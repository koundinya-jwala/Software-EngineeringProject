/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hellospring.spring.hellospring;

/**
 *
 * @author User
 */
import java.util.LinkedList;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.LinkedList;

public class OverallManager {
    //LinkedList<Thread> threadlist=new LinkedList<>();
    static Thread serverThread,threadManager;

    public static void main(String[] args) throws IOException {
        
        serverThread=new Thread(new Server("localhost",3000));
        threadManager=new Thread(new ThreadManager());
        
        serverThread.start();
        threadManager.start();
       
    }

}